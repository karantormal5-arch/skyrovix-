"""
Data cleaning for the Online Retail dataset (Customer Analytics Dashboard).

Input : OnlineRetail.csv  (541,909 rows, 8 columns)
Output: OnlineRetail_clean.csv (transaction level, 391,150 rows)
        customer_summary.csv   (one row per customer, 4,334 rows)

Usage : python data_cleaning.py --input OnlineRetail.csv --outdir output
"""
import argparse
import os

import pandas as pd

NON_PRODUCT_CODES = ["POST", "M", "C2", "DOT", "BANK CHARGES", "PADS"]


def clean(path):
    # utf-8-sig removes the BOM so the first column is read as "InvoiceNo"
    df = pd.read_csv(path, encoding="utf-8-sig", dtype={"InvoiceNo": str, "StockCode": str})
    print("Raw rows:", len(df))

    df["Description"] = df["Description"].str.strip().str.upper()
    df["Country"] = df["Country"].str.strip()

    df = df.drop_duplicates()
    print("After duplicates:", len(df))

    df = df.dropna(subset=["Description", "CustomerID"])
    print("After blank description/customer:", len(df))
    df["CustomerID"] = df["CustomerID"].astype(int).astype(str)

    df = df[~df["InvoiceNo"].str.startswith("C")]
    print("After cancellations:", len(df))

    df = df[(df["Quantity"] > 0) & (df["UnitPrice"] > 0)]
    print("After quantity/price check:", len(df))

    df = df[~df["StockCode"].isin(NON_PRODUCT_CODES)]
    print("After non-product removal:", len(df))

    # Handles both "12/1/10 8:26" (Excel export) and "2010-12-01 08:26:00" (ISO) formats
    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"], format="mixed").dt.normalize()
    df["Revenue"] = (df["Quantity"] * df["UnitPrice"]).round(2)
    df["InvoiceMonth"] = df["InvoiceDate"].dt.to_period("M").astype(str)
    return df


def customer_summary(df):
    inv = df.groupby(["CustomerID", "InvoiceNo"]).agg(
        InvoiceDate=("InvoiceDate", "min"),
        Country=("Country", "first"),
        Revenue=("Revenue", "sum"),
    ).reset_index()

    cust = inv.groupby("CustomerID").agg(
        Country=("Country", "first"),
        FirstPurchase=("InvoiceDate", "min"),
        LastPurchase=("InvoiceDate", "max"),
        Orders=("InvoiceNo", "nunique"),
        TotalRevenue=("Revenue", "sum"),
    ).reset_index()

    cust["TotalRevenue"] = cust["TotalRevenue"].round(2)
    cust["AvgOrderValue"] = (cust["TotalRevenue"] / cust["Orders"]).round(2)
    cust["Lifespan_days"] = (cust["LastPurchase"] - cust["FirstPurchase"]).dt.days
    cust["Segment"] = pd.qcut(cust["TotalRevenue"].rank(method="first"), 3,
                              labels=["Low", "Medium", "High"])
    cust["RepeatCustomer"] = cust["Orders"] > 1
    cust["OrderBucket"] = pd.cut(cust["Orders"], [0, 1, 2, 4, 1000],
                                 labels=["1", "2", "3-4", "5+"])
    return cust


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--outdir", default="output")
    args = parser.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    clean_df = clean(args.input)
    cust = customer_summary(clean_df)

    print("Invoices:", clean_df["InvoiceNo"].nunique())
    print("Customers:", clean_df["CustomerID"].nunique())
    print("Total revenue:", round(clean_df["Revenue"].sum(), 2))

    clean_df.to_csv(os.path.join(args.outdir, "OnlineRetail_clean.csv"), index=False, encoding="utf-8")
    cust.to_csv(os.path.join(args.outdir, "customer_summary.csv"), index=False, encoding="utf-8")
    print("Saved files to", args.outdir)


if __name__ == "__main__":
    main()
